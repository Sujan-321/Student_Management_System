from django.contrib.auth.decorators import login_required
from django.shortcuts import render


@login_required
def dashboard(request):
    """
    Student dashboard view.

    Replace the dummy data below with real querysets once your models
    (Student, Course, Enrollment, Attendance, Grade, Notice, etc.) exist.
    e.g. student = Student.objects.get(user=request.user)
         enrolled_courses = student.courses.all()
    """

    # ---- Dummy/placeholder data (swap with real model queries later) ----
    student = {
        "full_name": "Aarav Sharma",
        "roll_no": "CS-2023-014",
        "class_name": "BSc CSIT",
        "semester": "5th",
        "photo_url": None,  # falls back to a generated avatar in the template
    }

    enrolled_courses = [
        {"name": "Database Management Systems", "instructor": "Dr. R. Khadka", "credits": 3, "status": "Active"},
        {"name": "Operating Systems", "instructor": "Prof. S. Thapa", "credits": 4, "status": "Active"},
        {"name": "Web Technology", "instructor": "Ms. P. Gurung", "credits": 3, "status": "Active"},
        {"name": "Computer Networks", "instructor": "Dr. M. Adhikari", "credits": 3, "status": "Active"},
    ]

    attendance_percentage = 87

    attendance_by_subject = [
        {"name": "Database Management Systems", "percentage": 92},
        {"name": "Operating Systems", "percentage": 81},
        {"name": "Web Technology", "percentage": 88},
        {"name": "Computer Networks", "percentage": 85},
    ]

    recent_grades = [
        {"subject": "DBMS", "exam_name": "Mid-term", "marks_obtained": 42, "total_marks": 50, "letter_grade": "A"},
        {"subject": "OS", "exam_name": "Mid-term", "marks_obtained": 38, "total_marks": 50, "letter_grade": "B+"},
        {"subject": "Web Tech", "exam_name": "Assignment 2", "marks_obtained": 18, "total_marks": 20, "letter_grade": "A+"},
    ]

    overall_grade = "A-"
    pending_fees = 0

    notices = [
        {
            "title": "Mid-term Exam Routine Published",
            "date": "Jun 25, 2026",
            "description": "Check the notice board for your exam schedule and seating plan.",
        },
        {
            "title": "Library Hours Extended",
            "date": "Jun 20, 2026",
            "description": "Library will remain open until 9 PM during exam week.",
        },
    ]

    context = {
        "student": student,
        "enrolled_courses": enrolled_courses,
        "attendance_percentage": attendance_percentage,
        "attendance_by_subject": attendance_by_subject,
        "recent_grades": recent_grades,
        "overall_grade": overall_grade,
        "pending_fees": pending_fees,
        "notices": notices,
    }

    return render(request, "students/dashboard.html", context)
