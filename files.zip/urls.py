from django.urls import path
from django.contrib.auth.views import LogoutView
from . import views

# These names must match the {% url '...' %} tags used in base.html / dashboard.html
urlpatterns = [
    path("dashboard/", views.dashboard, name="dashboard"),
    path("profile/", views.dashboard, name="profile"),       # replace with a real profile view later
    path("courses/", views.dashboard, name="courses"),       # replace with a real courses view later
    path("attendance/", views.dashboard, name="attendance"), # replace with a real attendance view later
    path("grades/", views.dashboard, name="grades"),          # replace with a real grades view later
    path("logout/", LogoutView.as_view(), name="logout"),
]
